select customer_id, sum(spend) as total_spending from fact_spends where month= 'October' group by customer_id
order by customer_id; 